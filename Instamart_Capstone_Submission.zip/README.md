# Instamart Customer Intelligence & Support Copilot

## Project Overview
This project analyzes synthetic Instamart customer, order, product, and support ticket data. It demonstrates customer segmentation, ticket classification, privacy masking, policy retrieval, and refund eligibility testing.

## Tools Used
- Python
- Pandas
- SQLite
- Regular Expressions
- Mock LLM for offline testing
- Google Colab

## Main Components
1. Data cleaning and validation
2. SQLite database creation and SQL analysis
3. Customer segmentation and lapse analysis
4. Support ticket classification
5. Privacy masking
6. Policy question answering
7. Refund eligibility rules
8. Refund agent scenario testing

## Key Results
- 1,200 customers
- 40 products
- 12,309 unique order IDs in the cleaned database
- 164 support tickets
- 7 refund agent scenarios tested
- 7 of 7 scenarios passed the implemented rule-based tests

## Output Files
- customer_segments_lapse.csv
- classified_tickets.csv
- privacy_protected_tickets.csv
- refund_eligibility_results.csv
- refund_agent_test_results.csv

## Limitations
- The data is synthetic and fictional.
- Customer lapse analysis uses rule-based conditions.
- Refund agent scenario tests validate implemented rules and do not represent real payments.
- Refund request timing within the policy's seven-day window requires separate validation.
- Privacy masking uses patterns and does not guarantee complete anonymization.
- The mock LLM is an offline simulation, not a hosted language model.

## How to Run
Run the notebook cells in order in Google Colab. Ensure the required data files and policy documents are available before running the analysis.
